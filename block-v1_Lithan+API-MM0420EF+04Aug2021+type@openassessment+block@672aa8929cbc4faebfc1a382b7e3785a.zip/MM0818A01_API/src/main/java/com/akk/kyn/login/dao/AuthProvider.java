package com.akk.kyn.login.dao;

//Create enumeration for Local, Google and Facebook
public enum AuthProvider {
	local,
	google
}
