package com.akk.kyn.login.service;
import java.util.List;
import java.util.Optional;

import com.akk.kyn.login.dao.Store;



public interface StoreService {
	public List<Store> viewStores();
	public Optional<Store> getStore(int sid);
	public List<Store> searchByKey(String key);

}