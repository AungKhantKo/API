package com.akk.kyn.login.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.akk.kyn.login.dao.Store;
import com.akk.kyn.login.service.StoreService;

@RestController
@RequestMapping("/online")
@CrossOrigin("http://localhost:3000")
public class StoreController {
	@Autowired
	private StoreService storeService;
		
	@GetMapping("/view-stores")
	
    @PreAuthorize("hasRole('USER')")
	
	public List<Store> viewStores(){
		List<Store> stores = storeService.viewStores();
		return stores;
		}
	
	//Get Product API (Get by Id)
		@GetMapping(value = "/store/{sid}")
		@PreAuthorize("hasRole('USER')")
		public Optional<Store> getStore(@PathVariable int sid){
			return storeService.getStore(sid);
		}
		
		//Search By Keyword (Search By Car Make, Search By Car Model, Search By Car Registration, Search By Car Price Range)
		@GetMapping(value = "/store/search/{key}")
		@PreAuthorize("hasRole('USER')")
		public List<Store> searchByKey(@PathVariable String key){
			return storeService.searchByKey(key);
		}
		
		
}